import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import ModalScreen from './ModalScreen';
import FormScreen from './FormScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="ModalScreen">
        {/* Screen 1: Modal Screen with Button */}
        <Stack.Screen 
          name="ModalScreen" 
          component={ModalScreen}
          options={{ title: 'Home Screen' }}
        />
        
        {/* Screen 2: Form Screen */}
        <Stack.Screen 
          name="FormScreen" 
          component={FormScreen}
          options={{ title: 'Registration Form' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}