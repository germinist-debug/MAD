import React from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  Alert
} from 'react-native';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { useNavigation, useRoute } from '@react-navigation/native';

// Validation Schema using Yup
const formSchema = Yup.object().shape({
  name: Yup.string()
    .min(2, 'Name must be at least 2 characters')
    .max(50, 'Name too long')
    .required('Name is required'),
  email: Yup.string()
    .email('Invalid email address')
    .required('Email is required'),
  phone: Yup.string()
    .matches(/^[0-9]+$/, 'Must be only digits')
    .min(10, 'Must be 10 digits')
    .max(10, 'Must be 10 digits')
    .required('Phone is required'),
  password: Yup.string()
    .min(6, 'Password must be at least 6 characters')
    .required('Password is required'),
  age: Yup.number()
    .min(18, 'You must be at least 18 years old')
    .max(100, 'Invalid age')
    .required('Age is required')
    .typeError('Please enter a valid number'),
});

export default function FormScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  
  // Get the function passed from ModalScreen
  const { onFormSubmit } = route.params || {};

  // Handle form submission
  const handleSubmit = (values, { resetForm }) => {
    // Add timestamp to data
    const formData = {
      ...values,
      timestamp: new Date().toLocaleString()
    };

    console.log('Form Submitted:', formData);
    
    // If parent provided submit handler, call it
    if (onFormSubmit) {
      onFormSubmit(formData);
    }
    
    // Show success alert
    Alert.alert(
      '✅ Success!',
      'Your form has been submitted successfully.',
      [
        {
          text: 'OK',
          onPress: () => {
            resetForm(); // Clear form
            navigation.goBack(); // Go back to ModalScreen
          }
        }
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.keyboardView}
        >
          <ScrollView 
            contentContainerStyle={styles.scrollContainer}
            showsVerticalScrollIndicator={false}
          >
            {/* Form Header */}
            <View style={styles.header}>
              <Text style={styles.title}>📝 Registration Form</Text>
              <Text style={styles.subtitle}>
                Please fill in all required fields marked with *
              </Text>
            </View>

            {/* Formik Form */}
            <Formik
              initialValues={{
                name: '',
                email: '',
                phone: '',
                password: '',
                age: ''
              }}
              validationSchema={formSchema}
              onSubmit={handleSubmit}
            >
              {({ 
                handleChange, 
                handleBlur, 
                handleSubmit, 
                values, 
                errors, 
                touched,
                isValid 
              }) => (
                <View style={styles.form}>
                  
                  {/* Name Field */}
                  <View style={styles.fieldGroup}>
                    <Text style={styles.label}>
                      Full Name <Text style={styles.required}>*</Text>
                    </Text>
                    <TextInput
                      style={[
                        styles.input,
                        touched.name && errors.name && styles.inputError
                      ]}
                      placeholder="Enter your full name"
                      value={values.name}
                      onChangeText={handleChange('name')}
                      onBlur={handleBlur('name')}
                    />
                    {touched.name && errors.name && (
                      <Text style={styles.error}>
                        ⚠️ {errors.name}
                      </Text>
                    )}
                  </View>

                  {/* Email Field */}
                  <View style={styles.fieldGroup}>
                    <Text style={styles.label}>
                      Email Address <Text style={styles.required}>*</Text>
                    </Text>
                    <TextInput
                      style={[
                        styles.input,
                        touched.email && errors.email && styles.inputError
                      ]}
                      placeholder="Enter your email"
                      keyboardType="email-address"
                      autoCapitalize="none"
                      value={values.email}
                      onChangeText={handleChange('email')}
                      onBlur={handleBlur('email')}
                    />
                    {touched.email && errors.email && (
                      <Text style={styles.error}>
                        ⚠️ {errors.email}
                      </Text>
                    )}
                  </View>

                  {/* Phone Field */}
                  <View style={styles.fieldGroup}>
                    <Text style={styles.label}>
                      Phone Number <Text style={styles.required}>*</Text>
                    </Text>
                    <TextInput
                      style={[
                        styles.input,
                        touched.phone && errors.phone && styles.inputError
                      ]}
                      placeholder="Enter 10-digit phone number"
                      keyboardType="phone-pad"
                      value={values.phone}
                      onChangeText={handleChange('phone')}
                      onBlur={handleBlur('phone')}
                    />
                    {touched.phone && errors.phone && (
                      <Text style={styles.error}>
                        ⚠️ {errors.phone}
                      </Text>
                    )}
                  </View>

                  {/* Password Field */}
                  <View style={styles.fieldGroup}>
                    <Text style={styles.label}>
                      Password <Text style={styles.required}>*</Text>
                    </Text>
                    <TextInput
                      style={[
                        styles.input,
                        touched.password && errors.password && styles.inputError
                      ]}
                      placeholder="Enter password (min 6 characters)"
                      secureTextEntry
                      value={values.password}
                      onChangeText={handleChange('password')}
                      onBlur={handleBlur('password')}
                    />
                    {touched.password && errors.password && (
                      <Text style={styles.error}>
                        ⚠️ {errors.password}
                      </Text>
                    )}
                  </View>

                  {/* Age Field */}
                  <View style={styles.fieldGroup}>
                    <Text style={styles.label}>
                      Age <Text style={styles.required}>*</Text>
                    </Text>
                    <TextInput
                      style={[
                        styles.input,
                        touched.age && errors.age && styles.inputError
                      ]}
                      placeholder="Enter your age"
                      keyboardType="numeric"
                      value={values.age}
                      onChangeText={handleChange('age')}
                      onBlur={handleBlur('age')}
                    />
                    {touched.age && errors.age && (
                      <Text style={styles.error}>
                        ⚠️ {errors.age}
                      </Text>
                    )}
                  </View>

                  {/* Form Buttons */}
                  <View style={styles.buttonGroup}>
                    <TouchableOpacity
                      style={[
                        styles.submitButton,
                        !isValid && styles.submitButtonDisabled
                      ]}
                      onPress={handleSubmit}
                      disabled={!isValid}
                    >
                      <Text style={styles.submitButtonText}>
                        ✅ Submit Form
                      </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={styles.cancelButton}
                      onPress={() => navigation.goBack()}
                    >
                      <Text style={styles.cancelButtonText}>
                        ↩️ Back to Home
                      </Text>
                    </TouchableOpacity>
                  </View>

                  {/* Form Status */}
                  <View style={styles.status}>
                    <Text style={styles.statusText}>
                      {isValid ? '✅ Form is ready to submit' : '⚠️ Fill all fields correctly'}
                    </Text>
                    <Text style={styles.fieldCount}>
                      Fields filled: {
                        Object.values(values).filter(val => val.trim() !== '').length
                      } / 5
                    </Text>
                  </View>
                </View>
              )}
            </Formik>

            {/* Form Tips */}
            <View style={styles.tips}>
              <Text style={styles.tipsTitle}>💡 Tips:</Text>
              <Text style={styles.tip}>• Errors show when you leave a field</Text>
              <Text style={styles.tip}>• Submit button activates when all fields are valid</Text>
              <Text style={styles.tip}>• Phone must be 10 digits only</Text>
              <Text style={styles.tip}>• Minimum age is 18 years</Text>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  keyboardView: {
    flex: 1,
  },
  scrollContainer: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    marginBottom: 25,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
  form: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
  },
  fieldGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#444',
    marginBottom: 8,
  },
  required: {
    color: '#ff3b30',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 14,
    fontSize: 16,
    backgroundColor: '#fafafa',
  },
  inputError: {
    borderColor: '#ff3b30',
    backgroundColor: '#fff5f5',
  },
  error: {
    color: '#ff3b30',
    fontSize: 12,
    marginTop: 5,
  },
  buttonGroup: {
    marginTop: 10,
  },
  submitButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
  },
  submitButtonDisabled: {
    backgroundColor: '#a5d6a7',
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cancelButton: {
    backgroundColor: 'transparent',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  cancelButtonText: {
    color: '#666',
    fontSize: 16,
  },
  status: {
    marginTop: 20,
    padding: 12,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    alignItems: 'center',
  },
  statusText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginBottom: 5,
  },
  fieldCount: {
    fontSize: 12,
    color: '#666',
  },
  tips: {
    backgroundColor: '#e3f2fd',
    borderRadius: 12,
    padding: 18,
  },
  tipsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1565C0',
    marginBottom: 10,
  },
  tip: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 6,
    marginLeft: 5,
  },
});