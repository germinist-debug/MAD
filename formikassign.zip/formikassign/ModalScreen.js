import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Modal,
  Button,
  Alert
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

export default function ModalScreen() {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [formData, setFormData] = useState(null);

  // Function to handle form submission from FormScreen
  const handleFormSubmit = (data) => {
    console.log('Form data received:', data);
    setFormData(data);
    Alert.alert(
      'Success!',
      `Form submitted successfully!\n\nName: ${data.name}\nEmail: ${data.email}`,
      [{ text: 'OK' }]
    );
  };

  // Navigate to Form Screen
  const navigateToForm = () => {
    navigation.navigate('FormScreen', {
      onFormSubmit: handleFormSubmit
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>📱 Modal & Form Demo</Text>
        <Text style={styles.subtitle}>Two Screen Navigation Example</Text>
      </View>

      {/* Main Content */}
      <View style={styles.content}>
        {/* Instruction Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>How It Works:</Text>
          <View style={styles.instruction}>
            <Text style={styles.bullet}>1.</Text>
            <Text style={styles.instructionText}>Click "Open Modal" to see a popup</Text>
          </View>
          <View style={styles.instruction}>
            <Text style={styles.bullet}>2.</Text>
            <Text style={styles.instructionText}>Click "Go to Form" in modal to navigate</Text>
          </View>
          <View style={styles.instruction}>
            <Text style={styles.bullet}>3.</Text>
            <Text style={styles.instructionText}>Fill & submit the form</Text>
          </View>
          <View style={styles.instruction}>
            <Text style={styles.bullet}>4.</Text>
            <Text style={styles.instructionText}>See success message back here</Text>
          </View>
        </View>

        {/* Button to Open Modal */}
        <TouchableOpacity
          style={styles.modalButton}
          onPress={() => setModalVisible(true)}
        >
          <Text style={styles.modalButtonText}>📲 Open Modal</Text>
        </TouchableOpacity>

        {/* Recent Submission */}
        {formData && (
          <View style={styles.submissionCard}>
            <Text style={styles.submissionTitle}>📋 Last Submission:</Text>
            <Text style={styles.submissionText}>Name: {formData.name}</Text>
            <Text style={styles.submissionText}>Email: {formData.email}</Text>
            <Text style={styles.submissionText}>
              Submitted: {formData.timestamp}
            </Text>
          </View>
        )}
      </View>

      {/* MODAL POPUP */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            {/* Modal Header */}
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>🚀 Welcome!</Text>
              <Text style={styles.modalText}>
                This is a modal popup. Click the button below to navigate to the Form Screen.
              </Text>
            </View>

            {/* Modal Content */}
            <View style={styles.modalContent}>
              <Text style={styles.modalInfo}>
                You will be taken to a Formik form screen where you can:
              </Text>
              
              <View style={styles.featureList}>
                <View style={styles.featureItem}>
                  <Text style={styles.featureIcon}>✓</Text>
                  <Text style={styles.featureText}>Fill a registration form</Text>
                </View>
                <View style={styles.featureItem}>
                  <Text style={styles.featureIcon}>✓</Text>
                  <Text style={styles.featureText}>See real-time validation</Text>
                </View>
                <View style={styles.featureItem}>
                  <Text style={styles.featureIcon}>✓</Text>
                  <Text style={styles.featureText}>Submit with Formik</Text>
                </View>
                <View style={styles.featureItem}>
                  <Text style={styles.featureIcon}>✓</Text>
                  <Text style={styles.featureText}>Return data back here</Text>
                </View>
              </View>
            </View>

            {/* Modal Buttons */}
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.navigateButton}
                onPress={() => {
                  setModalVisible(false); // Close modal
                  setTimeout(() => {
                    navigateToForm(); // Navigate to form
                  }, 300);
                }}
              >
                <Text style={styles.navigateButtonText}>📝 Go to Form Screen</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.closeModalButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.closeModalButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f4ff',
  },
  header: {
    backgroundColor: '#2196F3',
    padding: 25,
    paddingTop: 40,
    alignItems: 'center',
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: 'white',
  },
  subtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.9)',
    marginTop: 5,
  },
  content: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 20,
    marginBottom: 30,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  instruction: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  bullet: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2196F3',
    marginRight: 10,
  },
  instructionText: {
    fontSize: 15,
    color: '#555',
    flex: 1,
  },
  modalButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  modalButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  submissionCard: {
    backgroundColor: '#e8f5e9',
    borderRadius: 12,
    padding: 15,
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#c8e6c9',
  },
  submissionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2e7d32',
    marginBottom: 8,
  },
  submissionText: {
    fontSize: 14,
    color: '#555',
    marginBottom: 3,
  },
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: 'white',
    borderRadius: 20,
    width: '90%',
    maxWidth: 400,
    overflow: 'hidden',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  modalHeader: {
    backgroundColor: '#2196F3',
    padding: 25,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 10,
  },
  modalText: {
    fontSize: 15,
    color: 'rgba(255, 255, 255, 0.95)',
    textAlign: 'center',
    lineHeight: 22,
  },
  modalContent: {
    padding: 25,
  },
  modalInfo: {
    fontSize: 16,
    color: '#333',
    marginBottom: 15,
    fontWeight: '500',
  },
  featureList: {
    marginTop: 10,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureIcon: {
    fontSize: 18,
    color: '#4CAF50',
    marginRight: 12,
    fontWeight: 'bold',
  },
  featureText: {
    fontSize: 15,
    color: '#555',
  },
  modalButtons: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  navigateButton: {
    backgroundColor: '#FF9800',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
  },
  navigateButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  closeModalButton: {
    backgroundColor: 'transparent',
    borderRadius: 10,
    padding: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  closeModalButtonText: {
    color: '#666',
    fontSize: 15,
  },
});