import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyCNthTVMSLHi56L5vpn7fxjOGt7lakjU_A",
  authDomain: "studentportal-ae980.firebaseapp.com",
  projectId: "studentportal-ae980",
  storageBucket: "studentportal-ae980.firebasestorage.app",
  messagingSenderId: "211650640634",
  appId: "1:211650640634:web:9470573be57142a9756743"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;