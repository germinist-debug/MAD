import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './src/config/firebaseConfig';
import { isAdminUser } from './src/utils/adminSetup';

// Import screens
import SplashScreen from './src/screens/SplashScreen';
import LoginScreen from './src/screens/LoginScreen';
import SignupScreen from './src/screens/SignupScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import CourseEnrollmentScreen from './src/screens/CourseEnrollmentScreen';
import TimetableScreen from './src/screens/TimetableScreen';
import MotivationalQuotesScreen from './src/screens/MotivationalQuotesScreen';
import AdminDashboardScreen from './src/screens/AdminDashboardScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userRole, setUserRole] = useState('user');

  // Debug function to reset app state
  const resetAppForTesting = () => {
    console.log('🔄 App - Resetting app state for testing');
    setUser(null);
    setUserRole('user');
    setLoading(false);
  };

  useEffect(() => {
    console.log('🚀 App - Starting authentication listener');
    
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      console.log('👤 App - Auth state changed:', user ? 'User logged in' : 'No user');
      
      if (user) {
        console.log('🔍 App - Checking user role for:', user.email);
        
        // Check if user is admin
        const email = user.email;
        const isAdmin = await isAdminUser(email);
        console.log('🎭 App - User role:', isAdmin ? 'admin' : 'user');
        
        setUserRole(isAdmin ? 'admin' : 'user');
        
        // If admin, create/update admin record in Firestore
        if (isAdmin) {
          console.log('⚙️ App - Setting up admin user');
          const { checkAndCreateAdminInFirestore } = require('./src/utils/adminSetup');
          await checkAndCreateAdminInFirestore(email);
        }
      } else {
        setUserRole('user');
      }
      
      setUser(user);
      setLoading(false);
      
      if (user) {
        console.log('✅ App - Navigation ready for user:', user.email);
      }
    }, (error) => {
      console.error('❌ App - Auth state change error:', error);
      setLoading(false);
    });

    return () => {
      console.log('👋 App - Cleaning up auth listener');
      unsubscribe();
    };
  }, []);

  if (loading) {
    console.log('⏳ App - Still loading...');
    return null;
  }

  console.log('🎯 App - Current state:', {
    hasUser: !!user,
    role: userRole,
    email: user?.email
  });

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!user ? (
          <>
            <Stack.Screen name="Splash" component={SplashScreen} />
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Signup" component={SignupScreen} />
          </>
        ) : userRole === 'admin' ? (
          <>
            <Stack.Screen name="AdminDashboard" component={AdminDashboardScreen} />
          </>
        ) : (
          <>
            <Stack.Screen name="Profile" component={ProfileScreen} />
            <Stack.Screen name="CourseEnrollment" component={CourseEnrollmentScreen} />
            <Stack.Screen name="Timetable" component={TimetableScreen} />
            <Stack.Screen name="MotivationalQuotes" component={MotivationalQuotesScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}