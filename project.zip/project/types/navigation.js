// This file defines navigation types and constants
export const SCREENS = {
  SPLASH: 'Splash',
  LOGIN: 'Login',
  SIGNUP: 'Signup',
  PROFILE: 'Profile',
  COURSES: 'CourseEnrollment',
  TIMETABLE: 'Timetable',
  QUOTES: 'MotivationalQuotes',
};

// Sample course data
export const AVAILABLE_COURSES = [
  { id: '1', name: 'Introduction to Programming', credits: 3, code: 'CS101' },
  { id: '2', name: 'Data Structures', credits: 3, code: 'CS102' },
  { id: '3', name: 'Algorithms', credits: 3, code: 'CS103' },
  { id: '4', name: 'Database Systems', credits: 3, code: 'CS104' },
  { id: '5', name: 'Web Development', credits: 3, code: 'CS105' },
  { id: '6', name: 'Mobile App Development', credits: 3, code: 'CS106' },
  { id: '7', name: 'Software Engineering', credits: 3, code: 'CS107' },
  { id: '8', name: 'Artificial Intelligence', credits: 3, code: 'CS108' },
  { id: '9', name: 'Computer Networks', credits: 3, code: 'CS109' },
  { id: '10', name: 'Operating Systems', credits: 3, code: 'CS110' },
];