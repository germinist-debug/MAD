import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet, 
  ScrollView, 
  Alert, 
  Platform, 
  ActivityIndicator,
  Linking
} from 'react-native';
import { auth, db } from '../config/firebaseConfig';
import { signOut } from 'firebase/auth';
import { doc, onSnapshot, updateDoc, setDoc } from 'firebase/firestore';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { generateSapIdFromEmail } from '../utils/validation';

const ProfileScreen = ({ navigation }) => {
  const [userData, setUserData] = useState(null);
  const [cvUrl, setCvUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [cvInfo, setCvInfo] = useState(null);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    const user = auth.currentUser;
    if (user) {
      console.log('🔍 ProfileScreen - User logged in:', {
        uid: user.uid,
        email: user.email
      });
      
      const userDocRef = doc(db, 'students', user.uid);
      
      console.log('📄 ProfileScreen - Setting up Firestore listener for:', `students/${user.uid}`);
      
      const unsubscribe = onSnapshot(userDocRef, 
        async (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data();
            console.log('✅ ProfileScreen - Data loaded successfully:', {
              sapId: data.sapId,
              courses: data.enrolledCourses?.length || 0,
              hasCV: !!data.cvInfo
            });
            
            setUserData(data);
            if (data.cvInfo) {
              setCvInfo(data.cvInfo);
              setCvUrl(data.cvInfo.fileUri || null);
            } else {
              setCvInfo(null);
              setCvUrl(null);
            }
          } else {
            console.log('⚠️ ProfileScreen - No document found, creating default...');
            
            // Create initial user document
            const newUserData = {
              sapId: generateSapIdFromEmail(user.email),
              email: user.email,
              displayName: user.email?.split('@')[0] || 'Student',
              enrolledCourses: [],
              createdAt: new Date().toISOString(),
              cvInfo: null,
              lastLogin: new Date().toISOString()
            };
            
            try {
              await setDoc(userDocRef, newUserData);
              console.log('✅ ProfileScreen - Default user document created');
              setUserData(newUserData);
            } catch (error) {
              console.error('❌ ProfileScreen - Error creating document:', error);
              Alert.alert('Error', 'Failed to initialize profile');
            }
          }
          setIsInitialized(true);
        },
        (error) => {
          console.error('❌ ProfileScreen - Firestore error:', error);
          Alert.alert('Database Error', 'Failed to load profile data');
          setIsInitialized(true);
        }
      );

      return () => unsubscribe();
    } else {
      console.log('❌ ProfileScreen - No user logged in');
      setIsInitialized(true);
    }
  }, []);

  const handleLogout = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: async () => {
            try {
              // Save last login time before logging out
              if (auth.currentUser && userData) {
                const userDocRef = doc(db, 'students', auth.currentUser.uid);
                await updateDoc(userDocRef, {
                  lastLogin: new Date().toISOString()
                });
              }
              
              await signOut(auth);
              console.log('👋 ProfileScreen - User logged out successfully');
            } catch (error) {
              console.error('❌ ProfileScreen - Logout error:', error);
              Alert.alert('Logout Failed', error.message);
            }
          }
        }
      ]
    );
  };

  const uploadCV = async () => {
    try {
      setUploading(true);
      
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/pdf',
        copyToCacheDirectory: true,
      });

      if (result.canceled) {
        setUploading(false);
        return;
      }

      const user = auth.currentUser;
      if (!user) {
        Alert.alert('Error', 'User not authenticated');
        setUploading(false);
        return;
      }

      const sapId = generateSapIdFromEmail(user.email) || 'student';
      const fileUri = result.assets[0].uri;
      const fileName = `CV_${sapId}_${Date.now()}.pdf`;
      const documentsDir = FileSystem.documentDirectory;
      const permanentPath = `${documentsDir}${fileName}`;

      await FileSystem.copyAsync({
        from: fileUri,
        to: permanentPath
      });

      const userDocRef = doc(db, 'students', user.uid);
      const cvData = {
        fileName: fileName,
        originalName: result.assets[0].name || fileName,
        fileSize: result.assets[0].size,
        uploadedAt: new Date().toISOString(),
        status: 'stored_locally',
        fileUri: permanentPath,
        note: 'CV stored on device'
      };

      await updateDoc(userDocRef, {
        cvInfo: cvData
      });

      setCvUrl(permanentPath);
      setCvInfo(cvData);
      
      console.log('✅ CV uploaded successfully');
      Alert.alert('Success', '✅ CV uploaded successfully!');
      
    } catch (error) {
      console.error('❌ Upload error:', error);
      Alert.alert('Upload Failed', 'Failed to upload CV: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  const downloadCV = async () => {
    if (!cvUrl) {
      Alert.alert('No CV', 'Please upload your CV first.');
      return;
    }

    try {
      setDownloading(true);
      setDownloadProgress(0);
      
      const fileInfo = await FileSystem.getInfoAsync(cvUrl);
      
      if (!fileInfo.exists) {
        Alert.alert('File Not Found', 'The CV file could not be found. Please upload again.');
        setDownloading(false);
        return;
      }

      const sapId = generateSapIdFromEmail(auth.currentUser?.email) || 'student';
      const downloadFileName = `CV_${sapId}_${Date.now()}.pdf`;
      const downloadDir = FileSystem.documentDirectory;
      const downloadPath = `${downloadDir}${downloadFileName}`;

      Alert.alert('Downloading...', 'Your CV is being prepared for download. Please wait.', [
        { text: 'Cancel', onPress: () => setDownloading(false), style: 'cancel' }
      ]);

      const progressInterval = setInterval(() => {
        setDownloadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 300);

      await FileSystem.copyAsync({
        from: cvUrl,
        to: downloadPath
      });

      clearInterval(progressInterval);
      setDownloadProgress(100);
      await new Promise(resolve => setTimeout(resolve, 500));

      const canShare = await Sharing.isAvailableAsync();
      
      if (canShare) {
        Alert.alert(
          '✅ Download Complete!',
          `Your CV has been downloaded successfully.\n\nFile: ${downloadFileName}`,
          [
            { 
              text: 'OPEN FILE', 
              onPress: async () => {
                try {
                  await Sharing.shareAsync(downloadPath, {
                    mimeType: 'application/pdf',
                    dialogTitle: 'Open CV',
                    UTI: 'com.adobe.pdf'
                  });
                } catch (error) {
                  Alert.alert('Error', 'Could not open file. Please use a file manager to open it.');
                }
              },
              style: 'default'
            },
            { 
              text: 'OK', 
              style: 'cancel'
            }
          ]
        );
      } else {
        Alert.alert(
          '✅ Download Complete!',
          `Your CV has been downloaded.\n\nLocation: ${downloadPath}`,
          [
            { text: 'OK', style: 'default' },
            Platform.OS === 'android' ? {
              text: 'Open File Manager',
              onPress: () => {
                Linking.openURL('content://com.android.externalstorage.documents')
                  .catch(() => {
                    Alert.alert('Open Files', 'Please check your Downloads folder.');
                  });
              }
            } : null
          ].filter(Boolean)
        );
      }

    } catch (error) {
      console.error('❌ Download error:', error);
      Alert.alert(
        'Download Failed', 
        error.message || 'Failed to download CV. Please try again.'
      );
    } finally {
      setDownloading(false);
      setDownloadProgress(0);
    }
  };

  const viewCVDetails = () => {
    if (cvInfo) {
      Alert.alert(
        'CV Details',
        `📄 **File:** ${cvInfo.originalName || cvInfo.fileName}\n\n` +
        `💾 **Size:** ${cvInfo.fileSize ? (cvInfo.fileSize / 1024 / 1024).toFixed(2) + ' MB' : 'Unknown'}\n\n` +
        `📅 **Uploaded:** ${cvInfo.uploadedAt ? new Date(cvInfo.uploadedAt).toLocaleString() : 'Recently'}\n\n` +
        `📍 **Storage:** Local Device Storage`,
        [
          { text: 'Close', style: 'cancel' },
          { 
            text: 'Download CV', 
            onPress: downloadCV,
            style: 'default'
          }
        ]
      );
    } else {
      Alert.alert('No CV', 'Please upload your CV first.');
    }
  };

  const getTotalCredits = () => {
    if (!userData?.enrolledCourses) return 0;
    return userData.enrolledCourses.reduce((total, course) => total + course.credits, 0);
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '0 MB';
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
  };

  const formatDate = (dateValue) => {
    if (!dateValue) return 'Recently';
    try {
      if (typeof dateValue === 'string') {
        return new Date(dateValue).toLocaleDateString();
      } else if (dateValue.toDate) {
        return dateValue.toDate().toLocaleDateString();
      }
      return 'Recently';
    } catch (error) {
      return 'Recently';
    }
  };

  if (!isInitialized) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2c5282" />
        <Text style={styles.loadingText}>Loading your profile...</Text>
      </View>
    );
  }

  if (!userData) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2c5282" />
        <Text style={styles.loadingText}>Setting up your profile...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {userData.sapId ? userData.sapId.charAt(0) : 'S'}
            </Text>
          </View>
        </View>
        <Text style={styles.welcomeText}>Welcome back,</Text>
        <Text style={styles.nameText}>
          {userData.displayName || userData.email?.split('@')[0] || `Student #${userData.sapId}`}
        </Text>
        <Text style={styles.sapIdText}>SAP ID: {userData.sapId}</Text>
        {userData.lastLogin && (
          <Text style={styles.lastLoginText}>
            Last login: {formatDate(userData.lastLogin)}
          </Text>
        )}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Stats Cards */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{userData.enrolledCourses?.length || 0}</Text>
            <Text style={styles.statLabel}>Courses</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{getTotalCredits()}</Text>
            <Text style={styles.statLabel}>Credits</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{cvUrl ? '✓' : '—'}</Text>
            <Text style={styles.statLabel}>CV</Text>
          </View>
        </View>

        {/* Personal Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          <View style={styles.infoGrid}>
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>SAP ID</Text>
              <Text style={styles.infoValue}>{userData.sapId}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Email</Text>
              <Text style={styles.infoValue}>{auth.currentUser?.email}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Display Name</Text>
              <Text style={styles.infoValue}>
                {userData.displayName || auth.currentUser?.email?.split('@')[0] || 'Student'}
              </Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Member Since</Text>
              <Text style={styles.infoValue}>
                {userData.createdAt ? formatDate(userData.createdAt) : 'Recently'}
              </Text>
            </View>
          </View>
        </View>

        {/* CV Management */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>CV Management</Text>
          
          <View style={styles.cvStatus}>
            <View style={[styles.statusIndicator, cvUrl ? styles.statusActive : styles.statusInactive]} />
            <Text style={styles.cvStatusText}>
              {cvUrl ? '📱 CV Available (Local Storage)' : '❌ No CV Uploaded'}
            </Text>
          </View>

          {cvInfo && (
            <View style={styles.cvDetails}>
              <Text style={styles.cvDetailText}>📄 File: {cvInfo.originalName || cvInfo.fileName}</Text>
              <Text style={styles.cvDetailText}>💾 Size: {formatFileSize(cvInfo.fileSize)}</Text>
              <Text style={styles.cvDetailText}>📅 Uploaded: {formatDate(cvInfo.uploadedAt)}</Text>
              <Text style={styles.cvDetailText}>📱 Platform: {Platform.OS.toUpperCase()}</Text>
            </View>
          )}

          {/* Download Progress Bar */}
          {downloading && (
            <View style={styles.progressContainer}>
              <View style={styles.progressBar}>
                <View style={[styles.progressFill, { width: `${downloadProgress}%` }]} />
              </View>
              <Text style={styles.progressText}>
                Downloading... {downloadProgress}%
              </Text>
            </View>
          )}
          
          <TouchableOpacity 
            style={[styles.cvButton, uploading && styles.buttonDisabled]} 
            onPress={uploadCV}
            disabled={uploading || downloading}
          >
            {uploading ? (
              <View style={styles.buttonContent}>
                <ActivityIndicator color="white" size="small" />
                <Text style={[styles.cvButtonText, styles.buttonTextWithIndicator]}>
                  Uploading...
                </Text>
              </View>
            ) : (
              <Text style={styles.cvButtonText}>
                📄 {cvUrl ? 'Update CV' : 'Upload CV (PDF)'}
              </Text>
            )}
          </TouchableOpacity>

          {cvUrl && (
            <>
              <TouchableOpacity 
                style={[styles.cvButton, styles.viewButton]} 
                onPress={viewCVDetails}
                disabled={downloading}
              >
                <Text style={styles.cvButtonText}>👁️ View CV Details</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.cvButton, styles.downloadButton, downloading && styles.buttonDisabled]} 
                onPress={downloadCV}
                disabled={downloading || uploading}
              >
                {downloading ? (
                  <View style={styles.buttonContent}>
                    <ActivityIndicator color="white" size="small" />
                    <Text style={[styles.cvButtonText, styles.buttonTextWithIndicator]}>
                      Downloading...
                    </Text>
                  </View>
                ) : (
                  <Text style={styles.cvButtonText}>
                    ⬇️ Download CV
                  </Text>
                )}
              </TouchableOpacity>
            </>
          )}
          
          <Text style={styles.note}>
            💡 Your CV is stored locally on your device. Download to share with employers.
          </Text>
        </View>

        {/* Enrolled Courses */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Enrolled Courses</Text>
            <Text style={styles.creditSummary}>{getTotalCredits()}/20 credits</Text>
          </View>
          
          {userData.enrolledCourses && userData.enrolledCourses.length > 0 ? (
            <View style={styles.coursesList}>
              {userData.enrolledCourses.map((course, index) => (
                <View key={course.id || index} style={styles.courseCard}>
                  <View style={styles.courseInfo}>
                    <Text style={styles.courseCode}>{course.code}</Text>
                    <Text style={styles.courseName}>{course.name}</Text>
                  </View>
                  <View style={styles.creditBadge}>
                    <Text style={styles.creditText}>{course.credits} CR</Text>
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateIcon}>📚</Text>
              <Text style={styles.emptyStateText}>No courses enrolled yet</Text>
              <Text style={styles.emptyStateSubtext}>Start by enrolling in some courses</Text>
            </View>
          )}
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionsGrid}>
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => navigation.navigate('CourseEnrollment')}
            >
              <Text style={styles.actionIcon}>🎯</Text>
              <Text style={styles.actionText}>Enroll in Courses</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => navigation.navigate('Timetable')}
            >
              <Text style={styles.actionIcon}>🕒</Text>
              <Text style={styles.actionText}>View Timetable</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => navigation.navigate('MotivationalQuotes')}
            >
              <Text style={styles.actionIcon}>💫</Text>
              <Text style={styles.actionText}>Get Inspired</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Logout Button */}
        <TouchableOpacity 
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <Text style={styles.logoutButtonText}>🚪 Logout</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f7ff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f7ff',
  },
  loadingText: {
    color: '#4a5568',
    fontSize: 16,
    fontWeight: '500',
    marginTop: 10,
  },
  header: {
    backgroundColor: '#2c5282',
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 24,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    alignItems: 'center',
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  avatarContainer: {
    marginBottom: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    backgroundColor: '#1a365d',
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#1a365d',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
    borderWidth: 3,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  avatarText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
  },
  welcomeText: {
    color: '#e2e8f0',
    fontSize: 16,
    marginBottom: 4,
  },
  nameText: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  sapIdText: {
    color: '#d69e2e',
    fontSize: 14,
    fontWeight: '600',
  },
  lastLoginText: {
    color: '#a0aec0',
    fontSize: 12,
    marginTop: 4,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  statCard: {
    backgroundColor: '#f7fafc',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 6,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statNumber: {
    color: '#2c5282',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#4a5568',
    fontSize: 12,
    fontWeight: '500',
  },
  section: {
    backgroundColor: '#f7fafc',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    color: '#1a365d',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  creditSummary: {
    color: '#3182ce',
    fontSize: 14,
    fontWeight: '600',
  },
  infoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  infoItem: {
    width: '48%',
    marginBottom: 16,
  },
  infoLabel: {
    color: '#4a5568',
    fontSize: 12,
    fontWeight: '500',
    marginBottom: 4,
  },
  infoValue: {
    color: '#1a202c',
    fontSize: 14,
    fontWeight: '600',
  },
  cvStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
    backgroundColor: '#f0fff4',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#c6f6d5',
  },
  statusIndicator: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 10,
  },
  statusActive: {
    backgroundColor: '#38a169',
  },
  statusInactive: {
    backgroundColor: '#c53030',
  },
  cvStatusText: {
    color: '#2d3748',
    fontSize: 14,
    fontWeight: '500',
  },
  cvDetails: {
    backgroundColor: '#ebf8ff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
    borderLeftWidth: 3,
    borderLeftColor: '#3182ce',
  },
  cvDetailText: {
    color: '#2d3748',
    fontSize: 12,
    marginBottom: 4,
  },
  progressContainer: {
    marginBottom: 15,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#e2e8f0',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#38a169',
    borderRadius: 4,
  },
  progressText: {
    color: '#4a5568',
    fontSize: 12,
    textAlign: 'center',
    fontWeight: '500',
  },
  cvButton: {
    backgroundColor: '#2c5282',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    width: '100%',
    marginBottom: 12,
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  viewButton: {
    backgroundColor: '#3182ce',
    shadowColor: '#3182ce',
  },
  downloadButton: {
    backgroundColor: '#38a169',
    shadowColor: '#38a169',
  },
  buttonDisabled: {
    backgroundColor: '#a0aec0',
    shadowColor: 'transparent',
  },
  cvButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonTextWithIndicator: {
    marginLeft: 8,
  },
  note: {
    fontSize: 12,
    color: '#4a5568',
    textAlign: 'center',
    marginTop: 10,
    fontStyle: 'italic',
    lineHeight: 16,
  },
  coursesList: {
    marginTop: 8,
  },
  courseCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#f7fafc',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderLeftWidth: 4,
    borderLeftColor: '#3182ce',
  },
  courseInfo: {
    flex: 1,
  },
  courseCode: {
    color: '#2c5282',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  courseName: {
    color: '#4a5568',
    fontSize: 12,
    opacity: 0.9,
  },
  creditBadge: {
    backgroundColor: 'rgba(49, 130, 206, 0.1)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  creditText: {
    color: '#3182ce',
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyState: {
    alignItems: 'center',
    padding: 20,
  },
  emptyStateIcon: {
    fontSize: 48,
    marginBottom: 12,
    color: '#a0aec0',
  },
  emptyStateText: {
    color: '#4a5568',
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 4,
  },
  emptyStateSubtext: {
    color: '#718096',
    fontSize: 12,
  },
  actionsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionCard: {
    backgroundColor: '#f7fafc',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 6,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  actionIcon: {
    fontSize: 24,
    marginBottom: 8,
    color: '#2c5282',
  },
  actionText: {
    color: '#2d3748',
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
  },
  logoutButton: {
    backgroundColor: 'rgba(197, 48, 48, 0.1)',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
    marginVertical: 20,
    borderWidth: 1,
    borderColor: 'rgba(197, 48, 48, 0.2)',
  },
  logoutButtonText: {
    color: '#c53030',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ProfileScreen;