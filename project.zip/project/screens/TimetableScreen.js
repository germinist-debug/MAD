import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions, Alert } from 'react-native';
import { auth, db } from '../config/firebaseConfig';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { generateSapIdFromEmail } from '../utils/validation';

const { width } = Dimensions.get('window');

const TimetableScreen = () => {
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [timetable, setTimetable] = useState([]);
  const [currentDay, setCurrentDay] = useState(new Date().getDay());
  const [isLoading, setIsLoading] = useState(true);
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    console.log('🕒 TimetableScreen - Component mounted');
    fetchUserData();
  }, []);

  const fetchUserData = () => {
    const user = auth.currentUser;
    if (user) {
      console.log('📋 TimetableScreen - Setting up listener for user:', user.uid);
      
      const userDocRef = doc(db, 'students', user.uid);
      
      const unsubscribe = onSnapshot(userDocRef, 
        async (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data();
            console.log('✅ TimetableScreen - Data loaded:', {
              courses: data.enrolledCourses?.length || 0,
              hasData: !!data
            });
            
            setUserData(data);
            setEnrolledCourses(data.enrolledCourses || []);
            
            if (data.enrolledCourses && data.enrolledCourses.length > 0) {
              console.log('📅 Generating timetable for', data.enrolledCourses.length, 'courses');
              generateRealisticTimetable(data.enrolledCourses);
            } else {
              console.log('📅 No courses enrolled, showing empty timetable');
              setTimetable([]);
            }
          } else {
            console.log('⚠️ TimetableScreen - No document found, creating default...');
            
            const newUserData = {
              sapId: generateSapIdFromEmail(user.email),
              email: user.email,
              displayName: user.email?.split('@')[0] || 'Student',
              enrolledCourses: [],
              createdAt: new Date().toISOString(),
              timetable: []
            };
            
            try {
              await setDoc(userDocRef, newUserData);
              console.log('✅ TimetableScreen - Default document created');
              setUserData(newUserData);
              setEnrolledCourses([]);
              setTimetable([]);
            } catch (error) {
              console.error('❌ TimetableScreen - Error creating document:', error);
              Alert.alert('Error', 'Failed to load timetable data');
            }
          }
          setIsLoading(false);
        },
        (error) => {
          console.error('❌ TimetableScreen - Firestore error:', error);
          Alert.alert('Error', 'Failed to load timetable');
          setIsLoading(false);
        }
      );

      return () => unsubscribe();
    } else {
      console.log('❌ TimetableScreen - No user logged in');
      setIsLoading(false);
    }
  };

  const generateRealisticTimetable = (courses) => {
    console.log('🎨 Generating timetable for courses:', courses.length);
    
    const days = [
      { name: 'Monday', short: 'MON' },
      { name: 'Tuesday', short: 'TUE' },
      { name: 'Wednesday', short: 'WED' },
      { name: 'Thursday', short: 'THU' },
      { name: 'Friday', short: 'FRI' }
    ];
    
    const theoryTimeSlots = [
      { time: '8:00-9:30', period: '1', type: 'theory', start: 8, end: 9.5 },
      { time: '9:45-11:15', period: '2', type: 'theory', start: 9.75, end: 11.25 },
      { time: '11:30-1:00', period: '3', type: 'theory', start: 11.5, end: 13 },
      { time: '2:00-3:30', period: '4', type: 'theory', start: 14, end: 15.5 }
    ];

    const labTimeSlots = [
      { time: '8:00-10:00', period: 'L1', type: 'lab', start: 8, end: 10 },
      { time: '10:15-12:15', period: 'L2', type: 'lab', start: 10.25, end: 12.25 },
      { time: '1:00-3:00', period: 'L3', type: 'lab', start: 13, end: 15 },
      { time: '3:15-4:00', period: 'L4', type: 'lab', start: 15.25, end: 16 }
    ];

    const allTimeSlots = [...theoryTimeSlots, ...labTimeSlots];
    const courseSchedule = {};
    
    courses.forEach((course, index) => {
      const hasLab = course.code.includes('LAB') || Math.random() > 0.6;
      const courseDays = [];
      const totalDays = hasLab ? 2 : 3;
      
      for (let i = 0; i < totalDays; i++) {
        const dayIndex = (index + i) % days.length;
        if (!courseDays.includes(dayIndex)) {
          courseDays.push(dayIndex);
        }
      }
      
      courseSchedule[course.id] = courseDays.map(dayIndex => {
        const isLabSession = hasLab && Math.random() > 0.5;
        const availableSlots = isLabSession ? labTimeSlots : theoryTimeSlots;
        const timeSlotIndex = (index + dayIndex) % availableSlots.length;
        
        return {
          dayIndex,
          timeSlot: availableSlots[timeSlotIndex],
          room: isLabSession ? 
                `Lab ${100 + (dayIndex * 10) + (timeSlotIndex * 2)}` : 
                `R${100 + (dayIndex * 10) + (timeSlotIndex * 2)}`,
          type: isLabSession ? 'lab' : 'theory'
        };
      });

      if (hasLab) {
        const hasLabSession = courseSchedule[course.id].some(s => s.type === 'lab');
        if (!hasLabSession && courseSchedule[course.id].length > 0) {
          courseSchedule[course.id][0].type = 'lab';
          courseSchedule[course.id][0].room = `Lab ${100 + (courseSchedule[course.id][0].dayIndex * 10)}`;
          const labSlot = labTimeSlots[courseSchedule[course.id][0].dayIndex % labTimeSlots.length];
          courseSchedule[course.id][0].timeSlot = labSlot;
        }
      }
    });

    const generatedTimetable = days.map((day, dayIndex) => ({
      ...day,
      isToday: dayIndex + 1 === currentDay,
      slots: allTimeSlots.map(timeSlot => {
        const scheduledCourse = courses.find(course => {
          const schedule = courseSchedule[course.id];
          return schedule?.some(s => 
            s.dayIndex === dayIndex && 
            s.timeSlot.period === timeSlot.period
          );
        });

        if (scheduledCourse) {
          const schedule = courseSchedule[scheduledCourse.id].find(s => 
            s.dayIndex === dayIndex && s.timeSlot.period === timeSlot.period
          );
          return {
            ...timeSlot,
            course: scheduledCourse,
            room: schedule?.room || (timeSlot.type === 'lab' ? 'Lab 101' : 'R101'),
            sessionType: schedule?.type || 'theory'
          };
        }

        return {
          ...timeSlot,
          course: null,
          room: '',
          sessionType: timeSlot.type
        };
      })
    }));

    console.log('✅ Timetable generated with', courses.length, 'courses');
    setTimetable(generatedTimetable);
  };

  const getCourseColor = (courseCode, sessionType) => {
    const theoryColors = [
      '#2c5282', '#3182ce', '#0ea5e9', '#3b82f6', 
      '#2563eb', '#1d4ed8', '#3b82f6', '#2563eb'
    ];
    
    const labColors = [
      '#38a169', '#16a34a', '#22c55e', '#84cc16',
      '#15803d', '#166534', '#15803d', '#166534'
    ];
    
    const colors = sessionType === 'lab' ? labColors : theoryColors;
    const index = courseCode ? courseCode.charCodeAt(0) % colors.length : 0;
    return colors[index];
  };

  const getCurrentDaySchedule = () => {
    return timetable.find(day => day.isToday) || timetable[0];
  };

  const getTheorySessions = (slots) => {
    return slots.filter(slot => slot.sessionType === 'theory' && slot.course);
  };

  const getLabSessions = (slots) => {
    return slots.filter(slot => slot.sessionType === 'lab' && slot.course);
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading timetable...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.logoContainer}>
            <View style={styles.logoPlaceholder}>
              <Text style={styles.logoText}>R</Text>
            </View>
          </View>
          <Text style={styles.title}>Weekly Timetable</Text>
          <Text style={styles.subtitle}>
            {enrolledCourses.length > 0 
              ? `${enrolledCourses.length} enrolled courses • 8:00 AM - 4:00 PM` 
              : 'No courses enrolled yet'
            }
          </Text>
          {userData?.sapId && (
            <Text style={styles.sapId}>SAP ID: {userData.sapId}</Text>
          )}
        </View>
      </View>

      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {enrolledCourses.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateIcon}>📚</Text>
            <Text style={styles.emptyStateTitle}>No Courses Enrolled</Text>
            <Text style={styles.emptyStateText}>
              Enroll in courses to view your personalized timetable
            </Text>
          </View>
        ) : (
          <>
            {/* Today's Schedule Highlight */}
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Today's Schedule</Text>
                <View style={styles.todayBadge}>
                  <Text style={styles.todayBadgeText}>TODAY</Text>
                </View>
              </View>
              
              {getCurrentDaySchedule() && (
                <View style={styles.todaySchedule}>
                  {/* Theory Sessions */}
                  {getTheorySessions(getCurrentDaySchedule().slots).length > 0 && (
                    <View style={styles.sessionTypeSection}>
                      <Text style={styles.sessionTypeTitle}>📖 Theory Classes</Text>
                      {getTheorySessions(getCurrentDaySchedule().slots).map((slot, index) => (
                        <View key={index} style={styles.todaySlot}>
                          <View style={styles.timeContainer}>
                            <Text style={styles.periodText}>P{slot.period}</Text>
                            <Text style={styles.timeText}>{slot.time}</Text>
                          </View>
                          <View 
                            style={[
                              styles.todayCourseSlot,
                              { 
                                backgroundColor: getCourseColor(slot.course.code, 'theory'),
                              }
                            ]}
                          >
                            <View style={styles.courseHeader}>
                              <Text style={styles.courseCode}>{slot.course.code}</Text>
                              <View style={styles.theoryBadge}>
                                <Text style={styles.badgeText}>THEORY</Text>
                              </View>
                            </View>
                            <Text style={styles.courseName} numberOfLines={1}>
                              {slot.course.name}
                            </Text>
                            <View style={styles.courseMeta}>
                              <Text style={styles.roomText}>🏢 {slot.room}</Text>
                              <Text style={styles.creditsText}>📚 {slot.course.credits} CR</Text>
                            </View>
                          </View>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Lab Sessions */}
                  {getLabSessions(getCurrentDaySchedule().slots).length > 0 && (
                    <View style={styles.sessionTypeSection}>
                      <Text style={styles.sessionTypeTitle}>🔬 Lab Sessions</Text>
                      {getLabSessions(getCurrentDaySchedule().slots).map((slot, index) => (
                        <View key={index} style={styles.todaySlot}>
                          <View style={styles.timeContainer}>
                            <Text style={styles.periodText}>L{slot.period.replace('L', '')}</Text>
                            <Text style={styles.timeText}>{slot.time}</Text>
                          </View>
                          <View 
                            style={[
                              styles.todayCourseSlot,
                              { 
                                backgroundColor: getCourseColor(slot.course.code, 'lab'),
                              }
                            ]}
                          >
                            <View style={styles.courseHeader}>
                              <Text style={styles.courseCode}>{slot.course.code}</Text>
                              <View style={styles.labBadge}>
                                <Text style={styles.badgeText}>LAB</Text>
                              </View>
                            </View>
                            <Text style={styles.courseName} numberOfLines={1}>
                              {slot.course.name}
                            </Text>
                            <View style={styles.courseMeta}>
                              <Text style={styles.roomText}>🔬 {slot.room}</Text>
                              <Text style={styles.creditsText}>⚗️ {slot.course.credits} CR</Text>
                            </View>
                          </View>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Free Periods */}
                  {getCurrentDaySchedule().slots.filter(slot => !slot.course).length > 0 && (
                    <View style={styles.freePeriodsSection}>
                      <Text style={styles.sessionTypeTitle}>☕ Free Periods</Text>
                      <View style={styles.freePeriodsGrid}>
                        {getCurrentDaySchedule().slots
                          .filter(slot => !slot.course)
                          .map((slot, index) => (
                            <View key={index} style={styles.freePeriodChip}>
                              <Text style={styles.freePeriodText}>{slot.time}</Text>
                            </View>
                          ))
                        }
                      </View>
                    </View>
                  )}
                </View>
              )}
            </View>

            {/* Weekly Timetable */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Weekly Schedule</Text>
              
              <ScrollView 
                horizontal 
                showsHorizontalScrollIndicator={false}
                style={styles.daysScrollView}
              >
                <View style={styles.daysContainer}>
                  {timetable.map((day, index) => {
                    const theoryCount = getTheorySessions(day.slots).length;
                    const labCount = getLabSessions(day.slots).length;
                    
                    return (
                      <View 
                        key={day.name} 
                        style={[
                          styles.dayCard,
                          day.isToday && styles.dayCardToday
                        ]}
                      >
                        <Text style={[
                          styles.dayName,
                          day.isToday && styles.dayNameToday
                        ]}>
                          {day.short}
                        </Text>
                        <Text style={[
                          styles.dayFullName,
                          day.isToday && styles.dayFullNameToday
                        ]}>
                          {day.name}
                        </Text>
                        
                        <View style={styles.dayStats}>
                          <View style={styles.sessionCount}>
                            <Text style={styles.theoryCount}>📖 {theoryCount}</Text>
                            <Text style={styles.labCount}>🔬 {labCount}</Text>
                          </View>
                        </View>
                      </View>
                    );
                  })}
                </View>
              </ScrollView>

              {/* Detailed Timetable */}
              <View style={styles.detailedTimetable}>
                {/* Time Slot Headers */}
                <View style={styles.timeHeaderColumn}>
                  <View style={[styles.timeHeader, styles.timeHeaderSpacer]} />
                  {timetable[0]?.slots.map((slot, index) => (
                    <View key={index} style={styles.timeHeader}>
                      <Text style={[
                        styles.timeHeaderPeriod,
                        slot.type === 'lab' && styles.labPeriod
                      ]}>
                        {slot.type === 'lab' ? `L${slot.period.replace('L', '')}` : `P${slot.period}`}
                      </Text>
                      <Text style={styles.timeHeaderText}>{slot.time}</Text>
                      <View style={[
                        styles.sessionTypeIndicator,
                        slot.type === 'lab' ? styles.labIndicator : styles.theoryIndicator
                      ]} />
                    </View>
                  ))}
                </View>

                {/* Day Columns */}
                {timetable.map((daySchedule) => (
                  <View key={daySchedule.name} style={styles.dayColumn}>
                    <View style={[
                      styles.dayHeader,
                      daySchedule.isToday && styles.dayHeaderToday
                    ]}>
                      <Text style={[
                        styles.dayHeaderText,
                        daySchedule.isToday && styles.dayHeaderTextToday
                      ]}>
                        {daySchedule.name}
                      </Text>
                    </View>
                    
                    {daySchedule.slots.map((slot, index) => (
                      <View 
                        key={index} 
                        style={[
                          styles.detailedSlot,
                          { 
                            backgroundColor: slot.course ? 
                              getCourseColor(slot.course.code, slot.sessionType) : 
                              '#f7fafc',
                          }
                        ]}
                      >
                        {slot.course ? (
                          <View style={styles.detailedCourse}>
                            <Text style={styles.detailedCourseCode}>{slot.course.code}</Text>
                            <View style={[
                              styles.sessionTypeBadge,
                              slot.sessionType === 'lab' ? styles.labTypeBadge : styles.theoryTypeBadge
                            ]}>
                              <Text style={styles.sessionTypeBadgeText}>
                                {slot.sessionType === 'lab' ? 'LAB' : 'THY'}
                              </Text>
                            </View>
                            <Text style={styles.detailedRoom}>{slot.room}</Text>
                          </View>
                        ) : (
                          <Text style={styles.detailedFree}>-</Text>
                        )}
                      </View>
                    ))}
                  </View>
                ))}
              </View>
            </View>

            {/* Course Summary */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Enrolled Courses Summary</Text>
              <View style={styles.coursesSummary}>
                {enrolledCourses.map((course, index) => {
                  const hasLab = timetable.some(day => 
                    day.slots.some(slot => 
                      slot.course?.id === course.id && slot.sessionType === 'lab'
                    )
                  );
                  
                  return (
                    <View key={course.id || index} style={styles.courseSummaryItem}>
                      <View style={styles.courseSummaryLeft}>
                        <View 
                          style={[
                            styles.courseColorDot,
                            { backgroundColor: getCourseColor(course.code, 'theory') }
                          ]} 
                        />
                        <View style={styles.courseSummaryInfo}>
                          <Text style={styles.courseSummaryCode}>{course.code}</Text>
                          <Text style={styles.courseSummaryName} numberOfLines={1}>
                            {course.name}
                          </Text>
                        </View>
                      </View>
                      <View style={styles.courseSummaryRight}>
                        {hasLab && (
                          <View style={styles.labIndicatorSmall}>
                            <Text style={styles.labIndicatorText}>LAB</Text>
                          </View>
                        )}
                        <Text style={styles.courseSummaryCredits}>{course.credits} CR</Text>
                      </View>
                    </View>
                  );
                })}
              </View>
            </View>
          </>
        )}

        {/* Debug Info */}
        {__DEV__ && (
          <View style={styles.debugInfo}>
            <Text style={styles.debugTitle}>Debug Info:</Text>
            <Text style={styles.debugText}>
              User: {auth.currentUser?.email}{'\n'}
              Courses: {enrolledCourses.length}{'\n'}
              SAP ID: {userData?.sapId}{'\n'}
              Current Day: {currentDay}
            </Text>
          </View>
        )}

        {/* Info Box */}
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Timetable Information:</Text>
          <Text style={styles.infoText}>
            • Timetable updates automatically with course enrollment{'\n'}
            • Theory classes shown in blue, labs in green{'\n'}
            • Room numbers assigned based on course type{'\n'}
            • Contact admin for any schedule conflicts
          </Text>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>Riphah International University</Text>
          <Text style={styles.footerSubtext}>Timetable Management System</Text>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f7ff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f7ff',
  },
  loadingText: {
    fontSize: 18,
    color: '#4a5568',
    fontWeight: '500',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 24,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  headerContent: {
    alignItems: 'center',
  },
  logoContainer: {
    marginBottom: 16,
  },
  logoPlaceholder: {
    width: 70,
    height: 70,
    backgroundColor: '#2c5282',
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  logoText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1a365d',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: '#4a5568',
    textAlign: 'center',
  },
  sapId: {
    fontSize: 12,
    color: '#2c5282',
    fontWeight: '600',
    marginTop: 4,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: '#ffffff',
    borderRadius: 20,
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  emptyStateIcon: {
    fontSize: 48,
    color: '#cbd5e0',
    marginBottom: 16,
  },
  emptyStateTitle: {
    color: '#1a365d',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  emptyStateText: {
    color: '#4a5568',
    fontSize: 14,
    textAlign: 'center',
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    color: '#1a365d',
    fontSize: 18,
    fontWeight: 'bold',
  },
  todayBadge: {
    backgroundColor: '#c53030',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  todayBadgeText: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold',
  },
  todaySchedule: {
    gap: 20,
  },
  sessionTypeSection: {
    gap: 12,
  },
  sessionTypeTitle: {
    color: '#1a202c',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  todaySlot: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  timeContainer: {
    width: 80,
    alignItems: 'center',
  },
  periodText: {
    color: '#2c5282',
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  timeText: {
    color: '#4a5568',
    fontSize: 11,
    fontWeight: '500',
  },
  todayCourseSlot: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    minHeight: 80,
    justifyContent: 'center',
  },
  courseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  courseCode: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  theoryBadge: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  labBadge: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  badgeText: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold',
  },
  courseName: {
    fontSize: 12,
    color: 'white',
    opacity: 0.9,
    marginBottom: 8,
  },
  courseMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  roomText: {
    fontSize: 10,
    color: 'white',
    opacity: 0.8,
  },
  creditsText: {
    fontSize: 10,
    color: 'white',
    opacity: 0.8,
  },
  freePeriodsSection: {
    marginTop: 8,
  },
  freePeriodsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  freePeriodChip: {
    backgroundColor: '#e6f0ff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#c3dafe',
  },
  freePeriodText: {
    color: '#2c5282',
    fontSize: 12,
    fontWeight: '500',
  },
  daysScrollView: {
    marginBottom: 20,
  },
  daysContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  dayCard: {
    backgroundColor: '#f7fafc',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    minWidth: 90,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  dayCardToday: {
    backgroundColor: '#e6f0ff',
    borderColor: '#2c5282',
  },
  dayName: {
    color: '#4a5568',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  dayNameToday: {
    color: '#2c5282',
  },
  dayFullName: {
    color: '#718096',
    fontSize: 10,
    marginBottom: 8,
  },
  dayFullNameToday: {
    color: '#2c5282',
  },
  dayStats: {
    marginBottom: 8,
  },
  sessionCount: {
    flexDirection: 'row',
    gap: 8,
  },
  theoryCount: {
    color: '#2c5282',
    fontSize: 10,
    fontWeight: '500',
  },
  labCount: {
    color: '#38a169',
    fontSize: 10,
    fontWeight: '500',
  },
  detailedTimetable: {
    flexDirection: 'row',
    gap: 8,
  },
  timeHeaderColumn: {
    width: 70,
  },
  timeHeader: {
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
    backgroundColor: '#f7fafc',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  timeHeaderSpacer: {
    height: 40,
    backgroundColor: 'transparent',
    borderColor: 'transparent',
  },
  timeHeaderPeriod: {
    color: '#2c5282',
    fontSize: 10,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  labPeriod: {
    color: '#38a169',
  },
  timeHeaderText: {
    color: '#4a5568',
    fontSize: 9,
    textAlign: 'center',
    marginBottom: 4,
  },
  sessionTypeIndicator: {
    width: 4,
    height: 4,
    borderRadius: 2,
  },
  theoryIndicator: {
    backgroundColor: '#2c5282',
  },
  labIndicator: {
    backgroundColor: '#38a169',
  },
  dayColumn: {
    flex: 1,
  },
  dayHeader: {
    backgroundColor: '#f7fafc',
    padding: 8,
    borderRadius: 8,
    marginBottom: 6,
    alignItems: 'center',
    height: 40,
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  dayHeaderToday: {
    backgroundColor: '#e6f0ff',
    borderColor: '#2c5282',
  },
  dayHeaderText: {
    color: '#4a5568',
    fontSize: 12,
    fontWeight: 'bold',
  },
  dayHeaderTextToday: {
    color: '#2c5282',
  },
  detailedSlot: {
    height: 60,
    borderRadius: 8,
    marginBottom: 6,
    padding: 6,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  detailedCourse: {
    alignItems: 'center',
  },
  detailedCourseCode: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  sessionTypeBadge: {
    paddingHorizontal: 4,
    paddingVertical: 1,
    borderRadius: 3,
    marginBottom: 2,
  },
  theoryTypeBadge: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  labTypeBadge: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  sessionTypeBadgeText: {
    color: 'white',
    fontSize: 6,
    fontWeight: 'bold',
  },
  detailedRoom: {
    color: 'white',
    fontSize: 7,
    opacity: 0.8,
  },
  detailedFree: {
    color: '#a0aec0',
    fontSize: 10,
  },
  coursesSummary: {
    gap: 8,
  },
  courseSummaryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#f7fafc',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  courseSummaryLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  courseColorDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  courseSummaryInfo: {
    flex: 1,
  },
  courseSummaryCode: {
    color: '#1a202c',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  courseSummaryName: {
    color: '#4a5568',
    fontSize: 12,
  },
  courseSummaryRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  labIndicatorSmall: {
    backgroundColor: '#38a169',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  labIndicatorText: {
    color: 'white',
    fontSize: 8,
    fontWeight: 'bold',
  },
  courseSummaryCredits: {
    color: '#2c5282',
    fontSize: 12,
    fontWeight: 'bold',
  },
  debugInfo: {
    backgroundColor: '#fff5f5',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#fed7d7',
  },
  debugTitle: {
    color: '#c53030',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  debugText: {
    color: '#2d3748',
    fontSize: 12,
    lineHeight: 16,
    fontFamily: 'monospace',
  },
  infoBox: {
    backgroundColor: '#e6fffa',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#b2f5ea',
  },
  infoTitle: {
    color: '#234e52',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  infoText: {
    color: '#2d3748',
    fontSize: 12,
    lineHeight: 18,
  },
  footer: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 30,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  footerText: {
    color: '#4a5568',
    fontSize: 14,
    marginBottom: 4,
  },
  footerSubtext: {
    color: '#a0aec0',
    fontSize: 12,
  },
});

export default TimetableScreen;