import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator, Animated } from 'react-native';

const MotivationalQuotesScreen = () => {
  const [quote, setQuote] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [fadeAnim] = useState(new Animated.Value(0));

  const fetchQuote = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('https://zenquotes.io/api/random');
      const data = await response.json();
      
      if (data && data[0]) {
        const newQuote = {
          text: data[0].q,
          author: data[0].a
        };
        
        // Fade animation for quote change
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }).start(() => {
          setQuote(newQuote);
          Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
          }).start();
        });
      } else {
        setError('No quote received from API');
      }
    } catch (error) {
      setError('Failed to fetch quote: ' + error.message);
      // Fallback quotes in case API fails
      const fallbackQuotes = [
        {
          text: "The only way to do great work is to love what you do.",
          author: "Steve Jobs"
        },
        {
          text: "Education is the most powerful weapon which you can use to change the world.",
          author: "Nelson Mandela"
        },
        {
          text: "Your time is limited, don't waste it living someone else's life.",
          author: "Steve Jobs"
        }
      ];
      const randomQuote = fallbackQuotes[Math.floor(Math.random() * fallbackQuotes.length)];
      setQuote(randomQuote);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchQuote();
  }, []);

  const motivationalTips = [
    {
      icon: '🌅',
      title: 'Morning Routine',
      text: 'Start your day with positive affirmations and clear intentions'
    },
    {
      icon: '🎯',
      title: 'Goal Setting',
      text: 'Break big goals into small, manageable daily tasks'
    },
    {
      icon: '🏆',
      title: 'Celebrate Wins',
      text: 'Acknowledge and celebrate every small victory along the way'
    },
    {
      icon: '💪',
      title: 'Stay Persistent',
      text: 'Remember your "why" when challenges seem overwhelming'
    },
    {
      icon: '🤝',
      title: 'Positive Circle',
      text: 'Surround yourself with people who uplift and inspire you'
    },
    {
      icon: '📚',
      title: 'Continuous Learning',
      text: 'Embrace every opportunity to learn and grow daily'
    },
    {
      icon: '🧘',
      title: 'Mindfulness',
      text: 'Practice mindfulness to stay present and reduce stress'
    },
    {
      icon: '⚡',
      title: 'Energy Management',
      text: 'Focus on managing your energy, not just your time'
    }
  ];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.logoContainer}>
            <View style={styles.logoPlaceholder}>
              <Text style={styles.logoText}>R</Text>
            </View>
          </View>
          <Text style={styles.title}>Daily Inspiration</Text>
          <Text style={styles.subtitle}>Fuel your academic journey with motivation</Text>
        </View>
      </View>

      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Quote Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Today's Wisdom</Text>
            <View style={styles.quoteBadge}>
              <Text style={styles.quoteBadgeText}>💫 LIVE</Text>
            </View>
          </View>

          <View style={styles.quoteContainer}>
            {loading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#2c5282" />
                <Text style={styles.loadingText}>Connecting to wisdom...</Text>
              </View>
            ) : error && !quote ? (
              <View style={styles.errorContainer}>
                <Text style={styles.errorIcon}>⚠️</Text>
                <Text style={styles.errorTitle}>Connection Issue</Text>
                <Text style={styles.errorText}>{error}</Text>
              </View>
            ) : quote ? (
              <Animated.View style={[styles.quoteCard, { opacity: fadeAnim }]}>
                <Text style={styles.quoteIcon}>💬</Text>
                <Text style={styles.quoteText}>"{quote.text}"</Text>
                <View style={styles.authorContainer}>
                  <View style={styles.authorLine} />
                  <Text style={styles.quoteAuthor}>— {quote.author}</Text>
                </View>
              </Animated.View>
            ) : null}
          </View>

          <TouchableOpacity 
            style={[
              styles.quoteButton,
              loading && styles.buttonDisabled
            ]} 
            onPress={fetchQuote}
            disabled={loading}
          >
           
          </TouchableOpacity>
        </View>

        {/* Stats Section */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>📖</Text>
            <Text style={styles.statNumber}>100+</Text>
            <Text style={styles.statLabel}>Quotes</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>🌟</Text>
            <Text style={styles.statNumber}>50+</Text>
            <Text style={styles.statLabel}>Writers</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>💡</Text>
            <Text style={styles.statNumber}>∞</Text>
            <Text style={styles.statLabel}>Inspiration</Text>
          </View>
        </View>

        {/* Motivation Tips */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Success Habits</Text>
          <Text style={styles.sectionSubtitle}>
            Build these habits for academic and personal growth
          </Text>

          <View style={styles.tipsGrid}>
            {motivationalTips.map((tip, index) => (
              <View key={index} style={styles.tipCard}>
                <View style={styles.tipHeader}>
                  <Text style={styles.tipIcon}>{tip.icon}</Text>
                  <View style={styles.tipNumber}>
                    <Text style={styles.tipNumberText}>{index + 1}</Text>
                  </View>
                </View>
                <Text style={styles.tipTitle}>{tip.title}</Text>
                <Text style={styles.tipText}>{tip.text}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Daily Challenge */}
        <View style={[styles.section, styles.challengeSection]}>
          <Text style={styles.sectionTitle}>Today's Challenge</Text>
          <View style={styles.challengeCard}>
            <Text style={styles.challengeIcon}>🎯</Text>
            <Text style={styles.challengeTitle}>Academic Excellence</Text>
            <Text style={styles.challengeText}>
              Complete one task today that brings you closer to your academic goals. 
              No matter how small, take that step forward.
            </Text>
            <View style={styles.challengeProgress}>
              <View style={styles.progressBar}>
                <View style={styles.progressFill} />
              </View>
              <Text style={styles.progressText}>Ready to begin</Text>
            </View>
          </View>
        </View>

        {/* Inspiration Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Words to Live By</Text>
          <View style={styles.inspirationGrid}>
            <View style={styles.inspirationCard}>
              <Text style={styles.inspirationIcon}>🚀</Text>
              <Text style={styles.inspirationQuote}>
                "The future belongs to those who believe in the beauty of their dreams."
              </Text>
              <Text style={styles.inspirationAuthor}>- Eleanor Roosevelt</Text>
            </View>
            <View style={styles.inspirationCard}>
              <Text style={styles.inspirationIcon}>💎</Text>
              <Text style={styles.inspirationQuote}>
                "Education is the passport to the future, for tomorrow belongs to those who prepare for it today."
              </Text>
              <Text style={styles.inspirationAuthor}>- Malcolm X</Text>
            </View>
          </View>
        </View>
        
        {/* Info Box */}
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Inspiration Tips:</Text>
          <Text style={styles.infoText}>
            • Refresh daily for new motivational quotes{'\n'}
            • Share inspiring quotes with classmates{'\n'}
            • Write down quotes that resonate with you{'\n'}
            • Use quotes as daily affirmations
          </Text>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>Riphah International University</Text>
          <Text style={styles.footerSubtext}>Motivation & Wellness Portal</Text>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f7ff',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 24,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  headerContent: {
    alignItems: 'center',
  },
  logoContainer: {
    marginBottom: 16,
  },
  logoPlaceholder: {
    width: 70,
    height: 70,
    backgroundColor: '#2c5282',
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  logoText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1a365d',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#4a5568',
    textAlign: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  sectionTitle: {
    color: '#1a365d',
    fontSize: 20,
    fontWeight: 'bold',
  },
  sectionSubtitle: {
    color: '#4a5568',
    fontSize: 14,
    marginBottom: 20,
    lineHeight: 20,
  },
  quoteBadge: {
    backgroundColor: '#e6fffa',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#b2f5ea',
  },
  quoteBadgeText: {
    color: '#234e52',
    fontSize: 10,
    fontWeight: 'bold',
  },
  quoteContainer: {
    minHeight: 200,
    justifyContent: 'center',
    marginBottom: 20,
  },
  loadingContainer: {
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 12,
    color: '#4a5568',
    fontSize: 14,
  },
  errorContainer: {
    alignItems: 'center',
    padding: 30,
    backgroundColor: '#fff5f5',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#fed7d7',
  },
  errorIcon: {
    fontSize: 32,
    marginBottom: 12,
    color: '#c53030',
  },
  errorTitle: {
    color: '#c53030',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  errorText: {
    color: '#2d3748',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  quoteCard: {
    backgroundColor: '#f7fafc',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 8,
  },
  quoteIcon: {
    fontSize: 24,
    marginBottom: 16,
    textAlign: 'center',
    color: '#2c5282',
  },
  quoteText: {
    fontSize: 18,
    fontStyle: 'italic',
    color: '#1a202c',
    lineHeight: 26,
    marginBottom: 20,
    textAlign: 'center',
    fontWeight: '500',
  },
  authorContainer: {
    alignItems: 'flex-end',
  },
  authorLine: {
    width: 40,
    height: 2,
    backgroundColor: '#2c5282',
    marginBottom: 8,
  },
  quoteAuthor: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#2c5282',
    fontStyle: 'normal',
  },
  quoteButton: {
    backgroundColor: '#2c5282',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 8,
  },
  buttonDisabled: {
    backgroundColor: '#a0aec0',
    shadowColor: 'transparent',
  },
  quoteButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 6,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statIcon: {
    fontSize: 20,
    marginBottom: 8,
    color: '#2c5282',
  },
  statNumber: {
    color: '#1a202c',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#4a5568',
    fontSize: 12,
    fontWeight: '500',
  },
  tipsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  tipCard: {
    width: '48%',
    backgroundColor: '#f7fafc',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  tipHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  tipIcon: {
    fontSize: 20,
    color: '#2c5282',
  },
  tipNumber: {
    width: 22,
    height: 22,
    backgroundColor: '#2c5282',
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tipNumberText: {
    color: 'white',
    fontSize: 11,
    fontWeight: 'bold',
  },
  tipTitle: {
    color: '#1a202c',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 6,
  },
  tipText: {
    color: '#4a5568',
    fontSize: 12,
    lineHeight: 16,
  },
  challengeSection: {
    backgroundColor: '#e6f0ff',
    borderColor: '#c3dafe',
  },
  challengeCard: {
    alignItems: 'center',
    padding: 20,
  },
  challengeIcon: {
    fontSize: 40,
    marginBottom: 16,
    color: '#2c5282',
  },
  challengeTitle: {
    color: '#1a365d',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
    textAlign: 'center',
  },
  challengeText: {
    color: '#4a5568',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 20,
  },
  challengeProgress: {
    width: '100%',
  },
  progressBar: {
    height: 6,
    backgroundColor: '#e2e8f0',
    borderRadius: 3,
    marginBottom: 8,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    width: '30%',
    backgroundColor: '#2c5282',
    borderRadius: 3,
  },
  progressText: {
    color: '#2c5282',
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
  },
  inspirationGrid: {
    gap: 12,
  },
  inspirationCard: {
    backgroundColor: '#f7fafc',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  inspirationIcon: {
    fontSize: 24,
    marginBottom: 12,
    color: '#2c5282',
  },
  inspirationQuote: {
    color: '#1a202c',
    fontSize: 14,
    fontStyle: 'italic',
    lineHeight: 20,
    marginBottom: 12,
  },
  inspirationAuthor: {
    color: '#2c5282',
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'right',
  },
  infoBox: {
    backgroundColor: '#e6fffa',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#b2f5ea',
  },
  infoTitle: {
    color: '#234e52',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  infoText: {
    color: '#2d3748',
    fontSize: 12,
    lineHeight: 18,
  },
  footer: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 30,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  footerText: {
    color: '#4a5568',
    fontSize: 14,
    marginBottom: 4,
  },
  footerSubtext: {
    color: '#a0aec0',
    fontSize: 12,
  },
});

export default MotivationalQuotesScreen;