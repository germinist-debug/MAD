import { db } from '../config/firebaseConfig';
import { doc, setDoc, getDoc } from 'firebase/firestore';

// Admin email (must match what you created in Firebase Console)
const ADMIN_EMAIL = 'admin@riphah.edu.pk';

// Function to check if admin exists in Firestore
export const checkAndCreateAdminInFirestore = async (userEmail) => {
  try {
    // Only run for admin email
    if (userEmail !== ADMIN_EMAIL) return null;
    
    const adminDocRef = doc(db, 'adminUsers', userEmail);
    const adminDoc = await getDoc(adminDocRef);
    
    if (!adminDoc.exists()) {
      console.log('Creating admin record in Firestore...');
      
      // Create admin document in Firestore
      await setDoc(adminDocRef, {
        email: userEmail,
        role: 'admin',
        createdAt: new Date(),
        permissions: ['view_all_students', 'view_course_stats', 'generate_reports'],
        lastLogin: null
      });
      
      console.log('Admin record created in Firestore');
      return { email: userEmail, role: 'admin' };
    }
    
    // Update last login time
    await setDoc(adminDocRef, {
      lastLogin: new Date()
    }, { merge: true });
    
    return adminDoc.data();
  } catch (error) {
    console.error('Error checking/creating admin in Firestore:', error);
    return null;
  }
};

// Function to check if a user is admin
export const isAdminUser = async (userEmail) => {
  try {
    if (!userEmail) return false;
    
    // Check in Firestore adminUsers collection
    const adminDocRef = doc(db, 'adminUsers', userEmail);
    const adminDoc = await getDoc(adminDocRef);
    
    if (adminDoc.exists()) {
      const data = adminDoc.data();
      return data.role === 'admin';
    }
    
    // Fallback: Check if email matches admin pattern
    return userEmail === ADMIN_EMAIL || userEmail.includes('admin@');
  } catch (error) {
    console.error('Error checking admin status:', error);
    return false;
  }
};