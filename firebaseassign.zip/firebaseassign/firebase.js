// src/config/firebase.js
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore'; // Change to Firestore

// ✅ YOUR ACTUAL FIREBASE CONFIG
const firebaseConfig = {
  apiKey: "AIzaSyBEK3NxTXrhLvoxH0KgbvYSS_TnLUOMhw8",
  authDomain: "fir-authapp-b9888.firebaseapp.com",
  projectId: "fir-authapp-b9888",
  storageBucket: "fir-authapp-b9888.firebasestorage.app",
  messagingSenderId: "656481000252",
  appId: "1:656481000252:web:ab6124be56ddbbc3855c39"
};

// ✅ FIX: Check if Firebase is already initialized
let app;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp(); // if already initialized, use that one
}

export const auth = getAuth(app);
export const db = getFirestore(app); // Change to Firestore
export default app;