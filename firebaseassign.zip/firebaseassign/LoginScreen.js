// src/screens/LoginScreen.js
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  StatusBar,
  SafeAreaView,
  ImageBackground
} from 'react-native';
import { auth } from '../config/firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeLoading, setActiveLoading] = useState(null); // 'login' or 'register'

  const validateForm = () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password');
      return false;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return false;
    }
    
    if (password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return false;
    }
    
    return true;
  };

  const handleLogin = async () => {
    if (!validateForm()) return;

    setLoading(true);
    setActiveLoading('login');
    try {
      await signInWithEmailAndPassword(auth, email, password);
      Alert.alert('Welcome Back!', 'Enjoy your stay at Paradise Resort! 🏖️');
      // Navigation will be handled automatically by AppNavigator
    } catch (error) {
      let errorMessage = 'Login failed. Please try again.';
      
      switch (error.code) {
        case 'auth/invalid-credential':
        case 'auth/user-not-found':
        case 'auth/wrong-password':
          errorMessage = 'Invalid email or password. Please check your credentials.';
          break;
        case 'auth/network-request-failed':
          errorMessage = 'Network error. Please check your connection.';
          break;
        case 'auth/too-many-requests':
          errorMessage = 'Too many failed attempts. Please try again later.';
          break;
        default:
          errorMessage = error.message || errorMessage;
      }
      
      Alert.alert('Login Error', errorMessage);
    } finally {
      setLoading(false);
      setActiveLoading(null);
    }
  };

  const handleRegister = async () => {
    if (!validateForm()) return;

    setLoading(true);
    setActiveLoading('register');
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      Alert.alert(
        'Welcome to Paradise Resort! 🎉', 
        `Account created successfully for ${user.email}! You can now sign in to access our luxury amenities.`,
        [
          {
            text: 'Continue',
            onPress: () => {
              // Keep form filled for login
            }
          }
        ]
      );
    } catch (error) {
      let errorMessage = 'Registration failed. Please try again.';
      
      switch (error.code) {
        case 'auth/email-already-in-use':
          errorMessage = 'This email is already registered. Please sign in instead.';
          break;
        case 'auth/invalid-email':
          errorMessage = 'Invalid email address.';
          break;
        case 'auth/weak-password':
          errorMessage = 'Password should be at least 6 characters.';
          break;
        case 'auth/network-request-failed':
          errorMessage = 'Network error. Please check your connection.';
          break;
        default:
          errorMessage = error.message || errorMessage;
      }
      
      Alert.alert('Registration Error', errorMessage);
    } finally {
      setLoading(false);
      setActiveLoading(null);
    }
  };

  const clearForm = () => {
    setEmail('');
    setPassword('');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ImageBackground 
        source={{ uri: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80' }}
        style={styles.backgroundImage}
      >
        <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
        
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.container}
        >
          {/* Overlay */}
          <View style={styles.overlay} />
          
          <View style={styles.header}>
            <Text style={styles.title}>🏝️ Paradise Resort</Text>
            <Text style={styles.subtitle}>
              Your Luxury Getaway Awaits
            </Text>
          </View>

          <View style={styles.formContainer}>
            {/* Welcome Message */}
            <View style={styles.welcomeMessage}>
              <Text style={styles.welcomeTitle}>Welcome to Paradise</Text>
              <Text style={styles.welcomeText}>
                Sign in to your account or create a new one to access our luxury resort amenities
              </Text>
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>📧 Email Address</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter your email address"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                placeholderTextColor="#A8DADC"
                editable={!loading}
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>🔒 Password</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter your password"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                placeholderTextColor="#A8DADC"
                editable={!loading}
              />
              <Text style={styles.passwordHint}>
                Password must be at least 6 characters
              </Text>
            </View>

            {/* Buttons Container */}
            <View style={styles.buttonsContainer}>
              <TouchableOpacity 
                style={[
                  styles.loginButton, 
                  loading && activeLoading !== 'login' && styles.disabledButton
                ]} 
                onPress={handleLogin}
                disabled={loading && activeLoading !== 'login'}
              >
                {loading && activeLoading === 'login' ? (
                  <ActivityIndicator size="small" color="#ffffff" />
                ) : (
                  <Text style={styles.loginButtonText}>🚀 Sign In</Text>
                )}
              </TouchableOpacity>

              <TouchableOpacity 
                style={[
                  styles.registerButton, 
                  loading && activeLoading !== 'register' && styles.disabledButton
                ]} 
                onPress={handleRegister}
                disabled={loading && activeLoading !== 'register'}
              >
                {loading && activeLoading === 'register' ? (
                  <ActivityIndicator size="small" color="#1D3557" />
                ) : (
                  <Text style={styles.registerButtonText}>✨ Register Account</Text>
                )}
              </TouchableOpacity>
            </View>

            {/* Quick Actions */}
            <View style={styles.quickActions}>
              <TouchableOpacity 
                style={styles.clearButton} 
                onPress={clearForm}
                disabled={loading}
              >
                <Text style={styles.clearButtonText}>
                  🗑️ Clear Form
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>
              🌴 Experience luxury like never before at Paradise Resort
            </Text>
            <Text style={styles.footerSubtext}>
              Private beaches • Luxury suites • Fine dining • Spa treatments
            </Text>
          </View>
        </KeyboardAvoidingView>
      </ImageBackground>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#1D3557',
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(29, 53, 87, 0.7)',
  },
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 32,
    paddingTop: 80,
    paddingBottom: 32,
  },
  title: {
    fontSize: 42,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 12,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 10,
  },
  subtitle: {
    fontSize: 18,
    color: '#F1FAEE',
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 5,
  },
  formContainer: {
    paddingHorizontal: 32,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    marginHorizontal: 20,
    borderRadius: 20,
    paddingVertical: 32,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 10,
  },
  welcomeMessage: {
    backgroundColor: '#A8DADC',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    borderLeftWidth: 4,
    borderLeftColor: '#457B9D',
  },
  welcomeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1D3557',
    marginBottom: 8,
  },
  welcomeText: {
    fontSize: 14,
    color: '#457B9D',
    lineHeight: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1D3557',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#F1FAEE',
    borderWidth: 2,
    borderColor: '#A8DADC',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: '#1D3557',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  passwordHint: {
    fontSize: 12,
    color: '#457B9D',
    marginTop: 4,
    marginLeft: 4,
    fontStyle: 'italic',
  },
  buttonsContainer: {
    gap: 12,
    marginTop: 8,
  },
  loginButton: {
    backgroundColor: '#E63946',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#E63946',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  registerButton: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#1D3557',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  disabledButton: {
    opacity: 0.6,
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  registerButtonText: {
    color: '#1D3557',
    fontSize: 16,
    fontWeight: '600',
  },
  quickActions: {
    marginTop: 16,
    alignItems: 'center',
  },
  clearButton: {
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  clearButtonText: {
    color: '#457B9D',
    fontSize: 14,
    fontWeight: '500',
  },
  footer: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingBottom: 40,
    paddingHorizontal: 32,
  },
  footerText: {
    fontSize: 14,
    color: '#F1FAEE',
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 5,
    marginBottom: 8,
  },
  footerSubtext: {
    fontSize: 12,
    color: '#A8DADC',
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 5,
  },
});

export default LoginScreen;