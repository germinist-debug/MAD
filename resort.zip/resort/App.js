import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { BookingProvider } from './frontend/context/BookingContext';
import HomeScreen from './frontend/screens/HomeScreen';
import RoomsScreen from './frontend/screens/RoomsScreen';
import BookingDetailsScreen from './frontend/screens/BookingDetailsScreen';
import AsyncStorageScreen from './frontend/screens/AsyncStorageScreen';
import CounterScreen from './frontend/screens/CounterScreen';
import ContextDemoScreen from './frontend/screens/ContextDemoScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
      <BookingProvider>
        <NavigationContainer>
          <Stack.Navigator initialRouteName="Home">
            <Stack.Screen 
              name="Home" 
              component={HomeScreen} 
              options={{ title: 'Paradise Resort' }} 
            />
            <Stack.Screen 
              name="Rooms" 
              component={RoomsScreen} 
              options={{ title: 'Available Rooms' }} 
            />
            <Stack.Screen 
              name="BookingDetails" 
              component={BookingDetailsScreen} 
              options={{ title: 'Booking Details' }} 
            />
            <Stack.Screen 
              name="Bookings" 
              component={ContextDemoScreen} 
              options={{ title: 'My Bookings' }} 
            />
            <Stack.Screen 
              name="Profile" 
              component={ContextDemoScreen} 
              options={{ title: 'Profile' }} 
            />
            <Stack.Screen 
              name="AsyncStorageDemo" 
              component={AsyncStorageScreen} 
              options={{ title: 'Preferences' }} 
            />
            <Stack.Screen 
              name="CounterDemo" 
              component={CounterScreen} 
              options={{ title: 'Counter Demo' }} 
            />
            <Stack.Screen 
              name="ContextDemo" 
              component={ContextDemoScreen} 
              options={{ title: 'Context Demo' }} 
            />
          </Stack.Navigator>
        </NavigationContainer>
      </BookingProvider>
    </SafeAreaProvider>
  );
}