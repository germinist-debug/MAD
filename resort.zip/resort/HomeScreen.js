import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { globalStyles } from '../styles/styles';

const HomeScreen = ({ navigation }) => {
  const userData = {
    name: 'Guest',
    membership: 'Gold',
    points: 1500
  };

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>🌴 Paradise Resort</Text>
      
      {/* 2x2 Grid Layout */}
      <View style={styles.gridContainer}>
        {/* Left Column */}
        <View style={styles.column}>
          <TouchableOpacity
            style={[globalStyles.button, styles.gridButton]}
            onPress={() => navigation.navigate('Rooms', { data: userData })}
          >
            <Text style={globalStyles.buttonText}>View Rooms & Book</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[globalStyles.button, styles.gridButton]}
            onPress={() => navigation.navigate('Bookings')}
          >
            <Text style={globalStyles.buttonText}>My Bookings</Text>
          </TouchableOpacity>
        </View>

        {/* Right Column */}
        <View style={styles.column}>
          <TouchableOpacity
            style={[globalStyles.button, styles.gridButton]}
            onPress={() => navigation.navigate('Profile')}
          >
            <Text style={globalStyles.buttonText}>Profile & Settings</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[globalStyles.button, styles.gridButton]}
            onPress={() => navigation.navigate('AsyncStorageDemo')}
          >
            <Text style={globalStyles.buttonText}>Preferences</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Quick Actions */}
      <ScrollView style={styles.quickActions}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        
        <TouchableOpacity
          style={globalStyles.card}
          onPress={() => navigation.navigate('CounterDemo')}
        >
          <Text style={styles.actionText}>Counter Demo (useEffect)</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={globalStyles.card}
          onPress={() => navigation.navigate('ContextDemo')}
        >
          <Text style={styles.actionText}>Context API Demo</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  gridContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  column: {
    flex: 1,
    marginHorizontal: 5,
  },
  gridButton: {
    marginBottom: 15,
    height: 80,
    justifyContent: 'center',
  },
  quickActions: {
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#2c3e50',
  },
  actionText: {
    fontSize: 16,
    color: '#3498db',
  },
});

export default HomeScreen;