import React from 'react';
import { View, Text, FlatList, TouchableOpacity, Alert } from 'react-native';
import { globalStyles } from '../styles/styles';
import { useBooking } from '../context/BookingContext';

const RoomsScreen = ({ navigation, route }) => {
  const { rooms, bookRoom } = useBooking();
  const userData = route.params?.data;

  // Function to handle room booking
  const handleBookRoom = (room) => {
    if (!room.available) {
      Alert.alert('Not Available', 'This room is currently not available');
      return;
    }

    // Navigate to booking details screen
    navigation.navigate('BookingDetails', { 
      room,
      user: userData 
    });
  };

  // Render each room item
  const renderRoomItem = ({ item }) => (
    <TouchableOpacity 
      style={[
        globalStyles.card, 
        !item.available && { backgroundColor: '#ecf0f1' }
      ]}
      onPress={() => handleBookRoom(item)}
      disabled={!item.available}
    >
      <Text style={{ fontSize: 18, fontWeight: 'bold', color: item.available ? '#2c3e50' : '#7f8c8d' }}>
        {item.name} {!item.available && '(Not Available)'}
      </Text>
      <Text style={{ color: '#e74c3c', fontWeight: 'bold', marginVertical: 5 }}>
        ${item.price}/night
      </Text>
      <Text>Type: {item.type}</Text>
      <Text>Capacity: {item.capacity} guests</Text>
      <Text style={{ marginTop: 5 }}>
        Amenities: {item.amenities.join(', ')}
      </Text>
    </TouchableOpacity>
  );

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Available Rooms</Text>
      <Text style={{ textAlign: 'center', marginBottom: 20, color: '#7f8c8d' }}>
        Welcome, {userData?.name} ({userData?.membership} Member)
      </Text>
      
      <FlatList
        data={rooms}
        renderItem={renderRoomItem}
        keyExtractor={item => item.id.toString()}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

export default RoomsScreen;