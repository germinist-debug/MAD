import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { globalStyles } from '../styles/styles';
import { useBooking } from '../context/BookingContext';

const BookingDetailsScreen = ({ navigation, route }) => {
  const { room, user } = route.params;
  const { bookRoom } = useBooking();
  
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState('1');
  const [totalPrice, setTotalPrice] = useState(0);

  // useEffect with dependency array - runs when checkIn, checkOut, or guests change
  useEffect(() => {
    if (checkIn && checkOut) {
      const days = Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24));
      if (days > 0) {
        setTotalPrice(days * room.price);
      } else {
        setTotalPrice(0);
      }
    }
  }, [checkIn, checkOut, room.price]); // Dependency array

  const handleBooking = () => {
    if (!checkIn || !checkOut || !guests) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    if (new Date(checkIn) >= new Date(checkOut)) {
      Alert.alert('Error', 'Check-out date must be after check-in date');
      return;
    }

    try {
      const booking = bookRoom(room.id, checkIn, checkOut, parseInt(guests));
      Alert.alert(
        'Booking Confirmed!',
        `Your booking for ${room.name} has been confirmed.\nTotal: $${booking.totalPrice}`,
        [
          {
            text: 'OK',
            onPress: () => navigation.navigate('Bookings')
          }
        ]
      );
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };

  return (
    <ScrollView style={globalStyles.container}>
      <Text style={globalStyles.title}>Booking Details</Text>
      
      <View style={globalStyles.card}>
        <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 10 }}>
          {room.name}
        </Text>
        <Text>Price per night: ${room.price}</Text>
        <Text>Type: {room.type}</Text>
        <Text>Capacity: {room.capacity} guests</Text>
      </View>

      <TextInput
        style={globalStyles.input}
        placeholder="Check-in Date (YYYY-MM-DD)"
        value={checkIn}
        onChangeText={setCheckIn}
      />
      
      <TextInput
        style={globalStyles.input}
        placeholder="Check-out Date (YYYY-MM-DD)"
        value={checkOut}
        onChangeText={setCheckOut}
      />
      
      <TextInput
        style={globalStyles.input}
        placeholder="Number of Guests"
        value={guests}
        onChangeText={setGuests}
        keyboardType="numeric"
      />

      {totalPrice > 0 && (
        <View style={[globalStyles.card, { backgroundColor: '#d5f4e6' }]}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#27ae60' }}>
            Total: ${totalPrice}
          </Text>
        </View>
      )}

      <TouchableOpacity style={globalStyles.button} onPress={handleBooking}>
        <Text style={globalStyles.buttonText}>Confirm Booking</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

export default BookingDetailsScreen;