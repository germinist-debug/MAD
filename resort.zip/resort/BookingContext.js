import React, { createContext, useState, useContext } from 'react';

// Create Context
const BookingContext = createContext();

// Context Provider Component
export const BookingProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [rooms, setRooms] = useState([
    {
      id: 1,
      name: "Deluxe Sea View",
      type: "Deluxe",
      price: 200,
      capacity: 2,
      amenities: ["WiFi", "AC", "TV", "Balcony"],
      available: true
    },
    {
      id: 2,
      name: "Family Suite",
      type: "Suite",
      price: 350,
      capacity: 4,
      amenities: ["WiFi", "AC", "TV", "Kitchen", "Living Room"],
      available: true
    },
    {
      id: 3,
      name: "Luxury Villa",
      type: "Villa",
      price: 500,
      capacity: 6,
      amenities: ["WiFi", "AC", "TV", "Private Pool", "Kitchen"],
      available: false
    }
  ]);

  // Function to book a room
  const bookRoom = (roomId, checkIn, checkOut, guests) => {
    const room = rooms.find(r => r.id === roomId);
    if (!room) {
      throw new Error('Room not found');
    }
    
    const newBooking = {
      id: Date.now(),
      roomId,
      roomName: room.name,
      checkIn,
      checkOut,
      guests,
      totalPrice: room.price * Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24)),
      status: 'confirmed'
    };
    
    setBookings(prev => [...prev, newBooking]);
    return newBooking;
  };

  // Function to cancel booking
  const cancelBooking = (bookingId) => {
    setBookings(prev => prev.filter(booking => booking.id !== bookingId));
  };

  return (
    <BookingContext.Provider value={{
      user,
      setUser,
      bookings,
      bookRoom,
      cancelBooking,
      rooms
    }}>
      {children}
    </BookingContext.Provider>
  );
};

// Custom Hook to use Booking Context
export const useBooking = () => {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error('useBooking must be used within a BookingProvider');
  }
  return context;
};