import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Alert } from 'react-native';
import { globalStyles } from '../styles/styles';

const CounterScreen = () => {
  const [count, setCount] = useState(0);
  const [message, setMessage] = useState('');

  // useEffect with dependency array - runs when count changes
  useEffect(() => {
    if (count > 0) {
      setMessage(`Counter is positive: ${count}`);
    } else if (count < 0) {
      setMessage(`Counter is negative: ${count}`);
    } else {
      setMessage('Counter is zero');
    }

    // Cleanup function (componentWillUnmount equivalent)
    return () => {
      console.log('Counter component cleanup');
    };
  }, [count]); // Dependency on count

  // useEffect with empty dependency array - runs only once
  useEffect(() => {
    Alert.alert('Welcome', 'Counter demo loaded!');
    
    return () => {
      console.log('Component unmounting');
    };
  }, []); // Empty dependency array

  const increment = () => setCount(prev => prev + 1);
  const decrement = () => setCount(prev => prev - 1);
  const reset = () => setCount(0);

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Counter Demo</Text>
      
      <Text style={{ fontSize: 48, textAlign: 'center', marginVertical: 30 }}>
        {count}
      </Text>

      <Text style={{ 
        fontSize: 18, 
        textAlign: 'center', 
        marginBottom: 20,
        color: count > 0 ? '#27ae60' : count < 0 ? '#e74c3c' : '#7f8c8d'
      }}>
        {message}
      </Text>

      <TouchableOpacity style={globalStyles.button} onPress={increment}>
        <Text style={globalStyles.buttonText}>Increment (+)</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={[globalStyles.button, { backgroundColor: '#e74c3c' }]} 
        onPress={decrement}
      >
        <Text style={globalStyles.buttonText}>Decrement (-)</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={[globalStyles.button, { backgroundColor: '#7f8c8d' }]} 
        onPress={reset}
      >
        <Text style={globalStyles.buttonText}>Reset</Text>
      </TouchableOpacity>
    </View>
  );
};

export default CounterScreen;