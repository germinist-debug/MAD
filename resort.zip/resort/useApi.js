import { useState, useEffect } from 'react';

// Custom Hook for API calls (demonstrating useEffect with dependencies)
export const useApi = (url, options = {}) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Simulate API call with timeout
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock data - in real app, this would be fetch(url, options)
        const mockData = {
          message: "Data fetched successfully",
          timestamp: new Date().toISOString()
        };
        
        setData(mockData);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [url]); // Dependency array - effect runs when URL changes

  return { data, loading, error };
};