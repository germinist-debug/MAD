import React from 'react';
import { View, Text, TouchableOpacity, FlatList, Alert } from 'react-native';
import { globalStyles } from '../styles/styles';
import { useBooking } from '../context/BookingContext';

const ContextDemoScreen = () => {
  const { user, setUser, bookings, cancelBooking } = useBooking();

  const handleLogin = () => {
    setUser({
      name: 'John Doe',
      email: 'john@example.com',
      membership: 'Gold'
    });
    Alert.alert('Logged In', 'User context updated!');
  };

  const handleLogout = () => {
    setUser(null);
    Alert.alert('Logged Out', 'User context cleared!');
  };

  const handleCancelBooking = (bookingId) => {
    cancelBooking(bookingId);
    Alert.alert('Cancelled', 'Booking has been cancelled');
  };

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Context API Demo</Text>

      {/* User Section */}
      <View style={globalStyles.card}>
        <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10 }}>
          User Context
        </Text>
        {user ? (
          <View>
            <Text>Name: {user.name}</Text>
            <Text>Email: {user.email}</Text>
            <Text>Membership: {user.membership}</Text>
            <TouchableOpacity 
              style={[globalStyles.button, { marginTop: 10, backgroundColor: '#e74c3c' }]}
              onPress={handleLogout}
            >
              <Text style={globalStyles.buttonText}>Logout</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View>
            <Text>No user logged in</Text>
            <TouchableOpacity 
              style={[globalStyles.button, { marginTop: 10 }]}
              onPress={handleLogin}
            >
              <Text style={globalStyles.buttonText}>Login</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Bookings Section */}
      <View style={[globalStyles.card, { marginTop: 20 }]}>
        <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10 }}>
          Bookings Context ({bookings.length})
        </Text>
        
        {bookings.length === 0 ? (
          <Text>No bookings yet</Text>
        ) : (
          <FlatList
            data={bookings}
            keyExtractor={item => item.id.toString()}
            renderItem={({ item }) => (
              <View style={{ 
                padding: 10, 
                borderBottomWidth: 1, 
                borderBottomColor: '#ecf0f1',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <View>
                  <Text style={{ fontWeight: 'bold' }}>{item.roomName}</Text>
                  <Text>${item.totalPrice} • {item.guests} guests</Text>
                  <Text style={{ fontSize: 12, color: '#7f8c8d' }}>
                    {item.checkIn} to {item.checkOut}
                  </Text>
                </View>
                <TouchableOpacity 
                  onPress={() => handleCancelBooking(item.id)}
                  style={{ padding: 5 }}
                >
                  <Text style={{ color: '#e74c3c', fontWeight: 'bold' }}>Cancel</Text>
                </TouchableOpacity>
              </View>
            )}
          />
        )}
      </View>
    </View>
  );
};

export default ContextDemoScreen;