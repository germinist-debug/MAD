import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, Alert, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { globalStyles } from '../styles/styles';

const AsyncStorageScreen = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [savedPreferences, setSavedPreferences] = useState({});

  // useEffect with empty dependency array - runs only once when component mounts
  useEffect(() => {
    loadPreferences();
  }, []); // Empty dependency array

  const loadPreferences = async () => {
    try {
      const savedName = await AsyncStorage.getItem('userName');
      const savedEmail = await AsyncStorage.getItem('userEmail');
      
      if (savedName) setName(savedName);
      if (savedEmail) setEmail(savedEmail);
      
      setSavedPreferences({
        name: savedName,
        email: savedEmail
      });
    } catch (error) {
      console.log('Error loading preferences', error);
    }
  };

  const savePreferences = async () => {
    try {
      await AsyncStorage.setItem('userName', name);
      await AsyncStorage.setItem('userEmail', email);
      Alert.alert('Success', 'Preferences saved!');
      loadPreferences(); // Reload preferences
    } catch (error) {
      Alert.alert('Error', 'Failed to save preferences');
    }
  };

  const clearPreferences = async () => {
    try {
      await AsyncStorage.removeItem('userName');
      await AsyncStorage.removeItem('userEmail');
      setName('');
      setEmail('');
      setSavedPreferences({});
      Alert.alert('Success', 'Preferences cleared!');
    } catch (error) {
      Alert.alert('Error', 'Failed to clear preferences');
    }
  };

  return (
    <ScrollView style={globalStyles.container}>
      <Text style={globalStyles.title}>User Preferences</Text>
      
      <TextInput
        style={globalStyles.input}
        placeholder="Enter your name"
        value={name}
        onChangeText={setName}
      />
      
      <TextInput
        style={globalStyles.input}
        placeholder="Enter your email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />

      <Button title="Save Preferences" onPress={savePreferences} />
      <Button title="Clear Preferences" onPress={clearPreferences} color="#e74c3c" />

      {savedPreferences.name && (
        <View style={[globalStyles.card, { marginTop: 20 }]}>
          <Text style={{ fontWeight: 'bold' }}>Saved Preferences:</Text>
          <Text>Name: {savedPreferences.name}</Text>
          <Text>Email: {savedPreferences.email}</Text>
        </View>
      )}
    </ScrollView>
  );
};

export default AsyncStorageScreen;